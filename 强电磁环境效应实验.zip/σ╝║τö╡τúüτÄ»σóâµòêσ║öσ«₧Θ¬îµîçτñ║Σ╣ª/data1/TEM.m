M = readmatrix('20211111111/211111_2880v_Ch4.csv');
plot(M);